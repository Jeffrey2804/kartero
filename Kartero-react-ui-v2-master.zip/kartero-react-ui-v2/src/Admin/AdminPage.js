import React from 'react'
import Navbar from "../Components/Navbar";
// import Dashboard from "./pages/Dashboard";
import Sidebar from '../Components/Sidebar';
// import Account from './pages/Account/Account';

function AdminPage(){
    return (
        <div>
            <Navbar/>
            <Sidebar/>
        </div>
    )
}

export default AdminPage
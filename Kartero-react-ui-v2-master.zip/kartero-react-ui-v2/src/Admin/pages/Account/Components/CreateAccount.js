import React from 'react';
// import PaymentLandingPageNavBar from './Components/PaymentLandingPageNavBar';

import Stack from '@mui/material/Stack';
import "../../../../Styles/LandingPage.css";

import Button from '@mui/material/Button';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

import Divider from '@mui/material/Divider';
import { FormControl, MenuItem, Select, TextField } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { minWidth } from '@mui/system';
const theme = createTheme({
    palette: {
        primary: {

            main: '#FD9A08',
            contrastText: '#fff',
        },
        secondary: {

            main: '#FFFFFF',
        },
    },
});

function CreateAccount() {
    const navigate = useNavigate();
    const [subPackage, setSubPackage] = React.useState('');
    const handleChange = (event) => {
        setSubPackage(event.target.value);
        console.log("Sample " + event.target.value);
    };

    return (   
        <div className='adminPage'>
            <div className='adminPageHeader'>
                <div className='title'>
                    <label onClick={() => {previousClick();}}>
                        Onboarding 
                    </label>
                    <label> </label>
                    <label>
                        > Create New Account
                    </label>
                </div>
                
            </div>
            
            <div className='createAccount'>
                <ThemeProvider theme={theme}>
                    <div className='paymentLandingPage'>
                        <Stack
                            direction="column"
                            justifyContent="left"
                            alignItems="left"
                            spacing={4}
                        >

                            <Box sx={{ width: '650px' }}>
                                <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                                    <Grid item xs={12}>
                                        <div className='pageTitle'>
                                            Create Account
                                        </div>
                                    </Grid>
                                    <Grid item xs={12}></Grid>
                                    <Grid item xs={6}>
                                        <div className='title'>Merchant</div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='contentHolder'>
                                            <TextField fullWidth label='' id='fullWidth'/>
                                        </div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='title'>Username</div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='contentHolder'>
                                            <TextField fullWidth label='' id='fullWidth'/>
                                        </div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='title'>Email Address</div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='contentHolder'>
                                            <TextField fullWidth label='' id='fullWidth'/>
                                        </div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='title'>Password</div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='contentHolder'>
                                            <TextField fullWidth label='' id='fullWidth'/>
                                        </div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='title'>Confirm Password</div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='contentHolder'>
                                            <TextField fullWidth label='' id='fullWidth'/>
                                        </div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='title'>Subscription Start</div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='contentHolder'>
                                            <TextField fullWidth label='' id='fullWidth'/>
                                        </div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='title'>Subscription Package</div>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <div className='contentHolder'>
                                            <FormControl sx={{m: 0, minWidth: 315}} size="medium">
                                                <Select onChange={handleChange}>
                                                    <MenuItem value={'3 months'}>3 Months</MenuItem>
                                                    <MenuItem value={'6 months'}>6 Months</MenuItem>
                                                    <MenuItem value={'12 months'}>12 Months</MenuItem>
                                                </Select>
                                            </FormControl>
                                        </div>
                                    </Grid>
                                </Grid>
                            </Box>

                            <Grid
                                container
                                direction="row"
                                justifyContent="right"
                                alignItems="right"
                                columnGap={0}
                            >

                            
                                <Button onClick={() => {nextClick();}} 
                                    variant="contained" size="large" disableElevation>
                                    Next
                                </Button>
                            </Grid>
                        </Stack>
                    </div>
                </ThemeProvider >
            </div>
        </div>
        
    )

    function nextClick() {
        navigate(process.env.REACT_APP_PATH + "/onboardMap");
    }

    function previousClick() {
        navigate(process.env.REACT_APP_PATH + "/onboarding");
    }
}

export default CreateAccount
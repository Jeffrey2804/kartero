import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import Card from '@mui/material/Card';
import { Box } from '@mui/system';
import { Email, Payment, PeopleAlt, Sms } from '@mui/icons-material';
import { Typography } from '@mui/material';
import {styled} from '@mui/material/styles'

const columns = [
    {
        id : 'merchant',
        label : 'Merchant'
    },
    {
        id : 'emailSent',
        type: 'numeric',
        label: 'Total Emails Sent'
    },
    {
        id : 'smsSent',
        label: 'Total SMS Sent'
    },
    {
        id: 'transacCount',
        label: 'Transaction Count'
    },
    {
        id: 'subEndDate',
        label: 'Subscription End Date'
    }
]

function createData(
    merchant,
    emailSent,
    smsSent,
    transacCount,
    subEndDate
) {
    return {
        merchant,
        emailSent,
        smsSent,
        transacCount,
        subEndDate
    };
}



const rows = [
    createData('Merchant_11', 168, 268, 258, '01/05/2023'),
    createData('AzaPhil', 226, 226, 216, '03/03/2023'),
    createData('UAFSA', 554, 554, 534, '06/06/2023'),
    createData('AdCore', 762, 764, 742, '10/04/2023'),
    createData('Prime League', 304, 304, 264, '04/10/2024'),
    createData('Test', 304, 31, 64, '04/10/2024')
];

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));

function totalMerchant(merchants){
    return merchants.map(({merchant}) => merchant).reduce((sum) => sum + 1, 0)
}

function totalEmailSent(items){
    return items.map(({ emailSent }) => emailSent).reduce((sum, i) => sum + i, 0)
}

function totalSMSSent(items){
    return items.map(({ smsSent }) => smsSent).reduce((sum, i) => sum + i, 0)
}

function totalTransaction(items){
    return items.map(({ transacCount }) => transacCount).reduce((sum, i) => sum + i, 0)
}

const totalEmail = totalMerchant(rows);

export default function DashboardOverview() {
    const [page, setPage] = useState(0);
    const [merchantCount, setMerchantCount] = useState(totalMerchant(rows));
    const [emailSentCount, setEmailSentCount] = useState(totalEmailSent(rows));
    const [smsSentCount, setSmsSentCoun] = useState(totalSMSSent(rows));
    const [paymentTransactionCount, setPaymentTransactionCount] = useState(totalTransaction(rows));
    const [rowsPerPage, setRowsPerPage] = useState(50);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    }; 

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };

    return (
        <div className='adminPage'>
            <div className='adminPageHeader'>
                <div className='title'>
                    Dashboard
                </div>
                <Box sx={{display: 'flex', flexWrap: 'wrap', 
                '& > :not(style)': { m: 1, width: 195, height: 75},
                }}>
                    <Paper elevation={1}> 
                        <div className='icon'>
                            <PeopleAlt />
                            <span className='count'> {merchantCount}</span>
                        </div>
                        <Typography className='countLabel'>Number of Members</Typography>
                    </Paper>

                    <Paper elevation={1}> 
                        <div className='icon'>
                            <Email />
                            <span className='count'> {emailSentCount}</span>
                        </div>
                        <Typography className='countLabel'>Total Emails Sent</Typography>
                    </Paper>

                    <Paper elevation={1}> 
                        <div className='icon'>
                            <Sms />
                            <span className='count'> {smsSentCount}</span>
                        </div>
                        <Typography className='countLabel'>Total SMS Sent</Typography>
                    </Paper>

                    <Paper elevation={1}> 
                        <div className='icon'>
                            <Payment />
                            <span className='count'> {paymentTransactionCount}</span>
                        </div>
                        <Typography className='countLabel'>Total Payment Transaction</Typography>
                    </Paper>
                </Box>
            </div>

            <div className='adminPageContent'>
                <div className='title'>
                    Overview
                </div>
                {/* <Paper sx={{ width: '1300px', overflow: 'hidden'}}>
                    <TableContainer sx={{ maxHeight: 440 }}>
                        <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                            <TableRow>
                            {columns.map((column) => (
                                <TableCell
                                key={column.id}
                                align={column.align}
                                style={{ minWidth: column.minWidth }}
                                >
                                {column.label}
                                </TableCell>
                            ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows
                            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            .map((row) => {
                                return (
                                <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                                    {columns.map((column) => {
                                    const value = row[column.id];
                                    return (
                                        <TableCell key={column.id} align={column.align}>
                                        {column.format && typeof value === 'number'
                                            ? column.format(value)
                                            : value}
                                        </TableCell>
                                    );
                                    })}
                                </TableRow>
                                );
                            })}
                        </TableBody>
                        </Table>
                    </TableContainer>
                    <TablePagination
                        rowsPerPageOptions={[10, 25, 100]}
                        component="div"
                        count={rows.length}
                        rowsPerPage={rowsPerPage}
                        page={page}
                        onPageChange={handleChangePage}
                        onRowsPerPageChange={handleChangeRowsPerPage}
                    />
                </Paper> */}
                
                <Paper sx={{ width: '1300px', overflow: 'hidden'}}>
                    <TableContainer sx={{ maxHeight: 440 }}>
                        <Table sx={{minWidth: 700}}>
                            <TableHead>
                                <TableRow>
                                    <StyledTableCell align="center">Merchant</StyledTableCell>
                                    <StyledTableCell align="center">Total Email Sent</StyledTableCell>
                                    <StyledTableCell align="center">Total SMS Sent</StyledTableCell>
                                    <StyledTableCell align="center">Transaction Count</StyledTableCell>
                                    <StyledTableCell align="center">Subscription End Date</StyledTableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {rows.map((row) => (
                                    <TableRow key={row.merchant}>
                                        <StyledTableCell align="center">{row.merchant}</StyledTableCell>
                                        <StyledTableCell align="center">{row.emailSent}</StyledTableCell>
                                        <StyledTableCell align="center">{row.smsSent}</StyledTableCell>
                                        <StyledTableCell align="center">{row.transacCount}</StyledTableCell>
                                        <StyledTableCell align="center">{row.subEndDate}</StyledTableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Paper>
            </div>
        </div>
        
    );
}
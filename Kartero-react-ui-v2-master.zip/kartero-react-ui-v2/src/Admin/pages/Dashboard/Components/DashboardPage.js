import React, { useState, useEffect } from 'react';
import DashboardOverview from './DashboardOverview';
import '../../../../Styles/AdminPage.css'

function DashboardPage() {

    return(
        // <div className='AdminPage'>
        //     <DashboardOverview/>
        // </div> 
        <DashboardOverview/>
    );
}

export default DashboardPage
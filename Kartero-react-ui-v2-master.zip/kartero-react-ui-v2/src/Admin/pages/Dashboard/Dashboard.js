import React from 'react'
import AdminNavbar from '../../../Components/AdminNavbar';
import Sidebar from '../../../Components/Sidebar';
import "../../../Styles/AdminPage.css";
import DashboardPage from './Components/DashboardPage';

function Dashboard(){
    return(
        <div className='adminMainPage'>
            <AdminNavbar/>
            <Sidebar/>
            {/* <div className='AdminPage'>
                <h1 align = 'center'>Dashboard</h1>
            </div> */}
            <DashboardPage/>
        </div>
        
    )
}

export default Dashboard
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import Card from '@mui/material/Card';
import { Box } from '@mui/system';
import { Email, Payment, PeopleAlt, Sms } from '@mui/icons-material';
import { Typography } from '@mui/material';
import {styled} from '@mui/material/styles'

const columns = [
    {
        id : 'merchant',
        label : 'Merchant'
    },
    {
        id : 'emailSent',
        type: 'numeric',
        label: 'Total Emails Sent'
    },
    {
        id : 'smsSent',
        label: 'Total SMS Sent'
    },
    {
        id: 'transacCount',
        label: 'Transaction Count'
    },
    {
        id: 'subEndDate',
        label: 'Subscription End Date'
    }
]

function createData(
    merchant,
    emailSent,
    smsSent,
    transacCount,
    subEndDate
) {
    return {
        merchant,
        emailSent,
        smsSent,
        transacCount,
        subEndDate
    };
}

const rows = [
    createData('', '', '', '', '','','','',''),
    createData('', '', '', '', '','','','',''),
    createData('', '', '', '', '','','','',''),
    createData('', '', '', '', '','','','',''),
    createData('', '', '', '', '','','','',''),
    createData('', '', '', '', '','','','',''),
    createData('', '', '', '', '','','','',''),
    createData('', '', '', '', '','','','',''),
    createData('', '', '', '', '','','','',''),
    createData('', '', '', '', '','','','',''),
    createData('', '', '', '', '','','','',''),
    createData('', '', '', '', '','','','',''),
];

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));

export default function ExcelPreview() {
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(50);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    }; 

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };

    return (
        <div className='template'>

            <Box className='mainContentBox'>

                <Box className='billHolder'>
            {/* <div className='adminPageContent'> */}
                
                
                <Paper sx={{ width: '1300px', overflow: 'hidden'}}>
                    <TableContainer sx={{ maxHeight: 440 }}>
                        <Table sx={{minWidth: 700}}>
                            <TableHead>
                                <TableRow>
                                    <StyledTableCell align="center">Name</StyledTableCell>
                                    <StyledTableCell align="center">Address</StyledTableCell>
                                    <StyledTableCell align="center">Invoice No.</StyledTableCell>
                                    <StyledTableCell align="center">Date</StyledTableCell>
                                    <StyledTableCell align="center">Amount</StyledTableCell>
                                    <StyledTableCell align="center">Water Consumption</StyledTableCell>
                                    <StyledTableCell align="center">Due Date</StyledTableCell>
                                    <StyledTableCell align="center">Contact Person</StyledTableCell>
                                    <StyledTableCell align="center">Contact Number</StyledTableCell>
                               
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {rows.map((row) => (
                                    <TableRow key={row.merchant}>
                                        <StyledTableCell align="center">{row.merchant}</StyledTableCell>
                                        <StyledTableCell align="center">{row.emailSent}</StyledTableCell>
                                        <StyledTableCell align="center">{row.smsSent}</StyledTableCell>
                                        <StyledTableCell align="center">{row.transacCount}</StyledTableCell>
                                        <StyledTableCell align="center">{row.subEndDate}</StyledTableCell>
                                        <StyledTableCell align="center">{row.merchant}</StyledTableCell>
                                        <StyledTableCell align="center">{row.emailSent}</StyledTableCell>
                                        <StyledTableCell align="center">{row.smsSent}</StyledTableCell>
                                        <StyledTableCell align="center">{row.transacCount}</StyledTableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Paper>
            {/* </div> */}
            </Box>
            </Box>
            </div>
        
    );
}
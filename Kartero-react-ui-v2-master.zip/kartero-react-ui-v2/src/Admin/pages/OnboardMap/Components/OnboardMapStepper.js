import React, {useState} from 'react';
import Box from '@mui/material/Box';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import SelectPdf from './SelectPdf';
import PdfMapping from './PdfMapping';
import SelectHtml from './SelectHtml';
import HtmlMapping from './HtmlMapping';
import CreateSms from './CreateSms';
import ExcelPreview from './ExcelPreview';
import SetSchedule from './SetSchedule';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { green, orange } from '@mui/material/colors';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import StepButton from '@mui/material/StepButton';

const defaultTheme = createTheme({
    palette: {
      primary: {
        main: orange[500],
      },
      secondary: {
        main: green[500],
      },
    }
  });
  
  const outerTheme = createTheme({
    components: {
      MuiButton: {
        variants: [
          {
            props: { variant: 'dashed' },
            style: {
              textTransform: 'none',
              border: `2px solid ${defaultTheme.palette.primary.main}`,
              color: defaultTheme.palette.primary.main,
            },
          },
  
        ],
      },
      MuiStepConnector: {
        variants: [{
          props: { variant: "steps" },
          style: {
            border: `2px dashed ${defaultTheme.palette.primary.main}`,
            color: defaultTheme.palette.primary.main,
          },
        }],
      },
    },
  });

export default function OnboardMapStepper() {
    // const [page, setPage] = useState(0);
    // const conditionalComponent = () => {
    //     switch (page) {
    //         case 0:
    //             return <SelectPdf />;
    //         case 1:
    //             return <PdfMapping />;
    //         case 2:
    //             return <SelectHtml />;
    //         case 3:
    //             return <HtmlMapping />;
    //         default:
    //             return <SelectPdf />;
    //     }
    // }

    // function handleSubmit(){
    //     setPage(page + 1);
    // }

    // return(
    //     <div className='adminPage'>
    //         {conditionalComponent()}
    //         <Button onClick={handleSubmit}>
    //             {page === 0 || page === 1 ? "Next" : "Submit"}
    //         </Button>
    //         {page > 0 && <Button onClick={() => setPage(page-1)}>Back</Button>}
    //     </div>
    // )

    const steps = ['', '', '', '', ''
                    // , '', ''
                ];
    const [activeStep, setActiveStep] = React.useState(0);
    console.log("Active Step" + activeStep)
    const [completed, setCompleted] = React.useState({});

    // const [stepShown, setStepShow] = useState(0); 

    const [showTemplate, setShowTemplate] = useState(false);
    const [showSelectPDF, setShowSelectPDF] = useState(true);
    const [showPDFMapping, setShowPDFMapping] = useState(false);
    const [showSelectHTML, setShowSelectHTML] = useState(false);
    const [showHTMLMapping, setShowHTMLMapping] = useState(false);
    const [showCreateSMS, setShowCreateSMS] = useState(false);
    const [showExcelPreview, setShowExcelPreview] = useState(false);
    const [showSelectDefaultSchedule, setShowSelectDefaultSchedule] = useState(false);
    const [stepName, setStepName] = useState("Select PDF");
    const [currentStep, setCurrentStep] = useState(1);

    const totalSteps = () => {
        return steps.length;
    };

    const completedSteps = () => {
        return Object.keys(completed).length;
    };

    const isLastStep = () => {
        return activeStep === totalSteps() - 1;
    };

    const allStepsCompleted = () => {
        return completedSteps() === totalSteps();
    };

    const handleNext = () => {
        // const newActiveStep =
        // isLastStep() && !allStepsCompleted()
        //     ? // It's the last step, but not all steps have been completed,
        //     // find the first step that has been completed
        //     steps.findIndex((step, i) => !(step in completed))
        //     : activeStep + 1;
        // setActiveStep(newActiveStep);
        // setStepShow((step) => step + 1);
        showSteps();

        // setActiveStep(activeStep + 1);
        setCurrentStep(currentStep + 1);
        setActiveStep((prevActiveStep) => prevActiveStep + 1);

        
    };

    const handleBack = () => {
        console.log("Test:" +currentStep)
        // setStepShow((step) => step - 1);
        // setActiveStep((prevActiveStep) => prevActiveStep - 1);
        setCurrentStep(currentStep - 1);
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
        console.log("Test" + currentStep);
        showSteps();
      };

    function showSelectTemplate(){
        setShowTemplate(true);
        setShowSelectHTML(false);
    }

    function showSelectPDFPage() {
        setStepName("Select PDF");
        setShowSelectPDF(true);
        setShowPDFMapping(false);
        setShowSelectHTML(false);
        setShowSelectHTML(false);
        setShowCreateSMS(false);
        setShowExcelPreview(false);
        setShowSelectDefaultSchedule(false);
    }
    
    function showPDFMappingPage() {
        setStepName("PDF Mapping");
        setShowSelectPDF(false);
        setShowPDFMapping(true);
        setShowSelectHTML(false);
        setShowHTMLMapping(false);
        setShowCreateSMS(false);
        setShowExcelPreview(false);
        setShowSelectDefaultSchedule(false);
    }
    
    function showSelectHTMLPage() {
        setStepName("Select HTML");
        setShowSelectPDF(false);
        setShowPDFMapping(false);
        setShowSelectHTML(true);
        setShowHTMLMapping(false);
        setShowCreateSMS(false);
        setShowExcelPreview(false);
        setShowSelectDefaultSchedule(false);
    }
    
    function showHTMLMappingPage() {
        setStepName("HTML Mapping");
        setShowSelectPDF(false);
        setShowPDFMapping(false);
        setShowSelectHTML(false);
        setShowHTMLMapping(true);
        setShowCreateSMS(false);
        setShowExcelPreview(false);
        setShowSelectDefaultSchedule(false);
    }
    
    function showCreateSMSPage() {
        setStepName("Create SMS Text");
        setShowSelectPDF(false);
        setShowPDFMapping(false);
        setShowSelectHTML(false);
        setShowHTMLMapping(false);
        setShowCreateSMS(true);
        setShowExcelPreview(false);
        setShowSelectDefaultSchedule(false);
    }
    
    function showExcelPreviewPage() {
        setStepName("Excel Preview");
        setShowSelectPDF(false);
        setShowPDFMapping(false);
        setShowSelectHTML(false);
        setShowHTMLMapping(false);
        setShowCreateSMS(false);
        setShowExcelPreview(true);
        setShowSelectDefaultSchedule(false);
    }
    
    function showSelectDefaultSchedulePage() {
        setShowSelectPDF(false);
        setShowPDFMapping(false);
        setShowSelectHTML(false);
        setShowHTMLMapping(false);
        setShowCreateSMS(false);
        setShowExcelPreview(false);
        setShowSelectDefaultSchedule(true);
    }
    
    function showSteps( ){
        // console.log("Stepshow: " + stepShown);
        console.log("Active Step: " + currentStep);

        // if(activeStep === 0){
        //     showSelectPDFPage();
        //     return;
        // }
        // if (activeStep === 1){
        //     showPDFMappingPage();
        //     return;
        // }
        if(currentStep === 1){
            showSelectHTMLPage();
            return;
        }
        // if (activeStep === 3){
        //     showHTMLMappingPage();
        //     return;
        // }
        if(currentStep === 2){
            showCreateSMSPage();
            return;
        }
        if (currentStep === 3){
            showExcelPreviewPage();
            return;
        }
        if(currentStep === 4){
            showSelectDefaultSchedulePage();
            return;
        }

        // if(stepShown  === 1){
        // showSelectTemplate();
        // }
        // if(stepShown ===2){
        //     showSelectHtmlPage();
        // }
        // else if(stepShown  == 0){
        // showUpload();
        // }
        
        console.log("Show Template: " + showTemplate);
        console.log("Show Select HTML: " + showSelectHTML)
        // console.log("Step Shown: " + stepShown);
    }
    
      const handleStep = (step) => () => {
        setActiveStep(step);
      };
    
      const handleComplete = () => {
        const newCompleted = completed;
        newCompleted[activeStep] = true;
        setCompleted(newCompleted);
        handleNext();
      };
    
      const handleReset = () => {
        setActiveStep(0);
        setCompleted({});
      };

      return(
        <div className='adminPage'>
            {/* <div className='adminPageHeader' > */}
                <div className='title'>
                    <Typography sx={{ mt: 2, mb: 1, py: 1, 
                        textAlign: 'center', fontSize: 25, fontWeight: 'bold' }}>
                        {stepName}      
                    </Typography>
                </div>
            {/* </div> */}
            <ThemeProvider theme={outerTheme}>

                <Box className='stepperBox' >
                    <Stepper nonLinear activeStep={activeStep} alternativeLabel className='Stepper' >

                    {steps.map((label, index) => (
                        <Step key={label} 
                        // completed={completed[index]}  
                        >
                        <StepButton onClick={handleStep(index)} variant="steps" color='primary'>
                            {label}
                        </StepButton>
                        </Step>
                    ))}

                    </Stepper>
                    
                    {/* {showSelectTemplate?<SelectPdf /> : null} */}
                    {/* {showSelectPDFPage? <SelectPdf /> : null}
                    {showPDFMappingPage? <PdfMapping/> : null}
                    {showSelectHTMLPage? <SelectHtml /> : null}
                    {showHTMLMappingPage? <HtmlMapping/> : null}
                    {showCreateSMSPage? <CreateSms/> : null}
                    {showExcelPreviewPage? <ExcelPreview/> : null}
                    {showSelectDefaultSchedulePage? <SetSchedule/> : null} */}
                    
                    
                    {showSelectPDF? <SelectPdf /> : null}
                    {showPDFMapping? <PdfMapping/> : null}
                    {showSelectHTML? <SelectHtml /> : null}
                    {showHTMLMapping? <HtmlMapping/> : null}
                    {showCreateSMS? <CreateSms/> : null}
                    {showExcelPreview? <ExcelPreview/> : null}
                    {showSelectDefaultSchedule? <SetSchedule/> : null}

                    <div className='stepperButton'>
                    {allStepsCompleted() ? (
                        <React.Fragment>
                        <Typography sx={{ mt: 2, mb: 1 }}>
                            All steps completed - you&apos;re finished
                        </Typography>
                        <Box sx={{ display: 'flex', flexDirection: 'row', pt: 1 }}>
                            <Box sx={{ flex: '1 1 auto' }} />
                            <Button onClick={handleReset}>Reset</Button>
                        </Box>
                        </React.Fragment>
                    ) : (
                        <React.Fragment>
                            {/* <Typography sx={{ mt: 2, mb: 1, py: 1 }}>
                                Step {activeStep + 1}

                            </Typography> */}
                            <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
                                {/* <Button
                                color="secondary"
                                variant="dashed"
                                disabled={activeStep === 0}
                                onClick={handleBack}
                                // sx={{ mr: 1 }}
                                className='buttonBack'
                                disabled
                                >
                                <KeyboardArrowLeftIcon/>
                                Back
                                </Button> */}
                            
                            
                            <Box sx={{ flex: '1 1 auto' }} />

                                <Button onClick={handleNext}
                                color="secondary"
                                variant="dashed"
                                // disabled={nextButtonEnable}
                                >
                                {/* {completedSteps() === totalSteps() - 1
                                    ? 'Send'
                                    : 'Next'} */}
                                {activeStep === 0 || activeStep === 4 ? "Next" : "Submit"}
                                <KeyboardArrowRightIcon />
                                </Button>
                                {/* ))} */}
                            </Box>
                        </React.Fragment>
                    )}
                    {/* </div> */}
                    {/* <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
                        <Button
                        color="inherit"
                        disabled={activeStep === 0}
                        onClick={handleBack}
                        sx={{ mr: 1 }}
                        >
                        Back
                        </Button>
                        <Box sx={{ flex: '1 1 auto' }} />
                        {isStepOptional(activeStep) && (
                        <Button color="inherit" onClick={handleSkip} sx={{ mr: 1 }}>
                            Skip
                        </Button>
                        )}

                        <Button onClick={handleNext}>
                        {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
                        </Button>
                    </Box> */}
                    {/* </React.Fragment> */}
                
            {/* </Box> */}
        </div>
        </Box>
        </ThemeProvider>
    </div>
    
  );
}
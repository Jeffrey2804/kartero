import React, { useState, useEffect, useRef } from 'react'
// import '../../Styles/Template.css';
import Box from '@mui/material/Box';
import {styled} from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Card from '@mui/material/Card';

import samplePdf2 from '../../../../Images/samplePDF1.png';

import Grow from '@mui/material/Grow';

function createData(
    metadataField,
    headerName,
    dataType
) {
    return {
        metadataField,
        headerName,
        dataType
    };
}

const rows = [
    createData('Namefield', 'Name', 'Text'),
    createData('Addressfield', 'Address', 'Text'),
    createData('Invoicefield', 'Invoice#', 'Number'),
    createData('Datefield', 'Date', 'Date'),
    createData('Amountfield', 'Amount', 'Number'),
    createData('attribute0field', 'Water Consumption', 'Number')
];

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));


const options = {
    shouldForwardProp: (prop) => prop !== 'rounded',
};

function PdfMapping(props) {
    const [numPages, setNumPages] = useState(null);
    const [pageNumber, setPageNumber] = useState(1);
    const [colorSelected, setColorSelected] = useState({ color: 'red' });
    const [checked, setChecked] = React.useState(false);
    const ref = useRef(null);
    function onDocumentLoadSuccess({ numPages }) {
        setNumPages(numPages);
    }


    const templateSelected = event => {
      
        const cardSelected = ref.current;

        cardSelected.className = "cardSelected";
        console.log("items Selected " + event.currentTarget.className);
        //console.log(props.getName);
        setColorSelected({ color: 'orange' });

      //  props.templateId("793759");
    }

    useEffect(() => {
        setChecked((prev) => !prev);
        return () => {
            setChecked((prev) => !prev);
        };
    }, []);

    return (
        <div className='template'>

            <Box className='mainContentBox'>
                PDF MApping
                <Box className='billHolder'>
                    <Grow
                        in={checked}
                        style={{ transformOrigin: '0 0 0' }}
                        {...(checked ? { timeout: 1000 } : {})}
                    >
                        <Card ref={ref} className="card" onClick={templateSelected}  >
                            <Card.Img className="cardImage" variant="top" />
                            <Card.Body className="cardBody">
                                <img className='templateHolder' src={samplePdf2} />
                            </Card.Body>
                        </Card>
                    </Grow>
                </Box>
                <Paper sx={{ width: '1400px', overflow: 'hidden'}}>
                    <TableContainer sx={{ maxHeight: 540 }}>
                        <Table sx={{minWidth: 700}}>
                            <TableHead>
                                <TableRow>
                                    <StyledTableCell align="center">Metadata Field</StyledTableCell>
                                    <StyledTableCell align="center">CSV Header Name</StyledTableCell>
                                    <StyledTableCell align="center">Data Type</StyledTableCell>
                                    <StyledTableCell align="center"> </StyledTableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {rows.map((row) => (
                                    <TableRow key={row.merchant}>
                                        <StyledTableCell align="center">{row.metadataField}</StyledTableCell>
                                        <StyledTableCell align="center">{row.headerName}</StyledTableCell>
                                        <StyledTableCell align="center">{row.dataType}</StyledTableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Paper>


            </Box>

      
        </div >
    )
}

export default PdfMapping
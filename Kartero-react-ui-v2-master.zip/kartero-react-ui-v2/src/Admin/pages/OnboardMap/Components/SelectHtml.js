import React, { useState, useEffect, useRef } from 'react'
// import '../../Styles/Template.css';
import Box from '@mui/material/Box';
import Card from 'react-bootstrap/Card';

import samplePdf2 from '../../../../Images/email.png';

import Grow from '@mui/material/Grow';
import { Event } from '@mui/icons-material';
// import PDFViewer from '../Components/PDFViewer';

function SelectHtml() {
    const [numPages, setNumPages] = useState(null);
    const [pageNumber, setPageNumber] = useState(0);
    const [colorSelected, setColorSelected] = useState({ color: 'red' });
    // const [checked, setChecked] = React.useState(false);
    const ref = useRef(null);
    function onDocumentLoadSuccess({ numPages }) {
        setNumPages(numPages);
    }


    const templateSelected = event => {
      
        const cardSelected = ref.current;

        cardSelected.className = "cardSelected";
        console.log("items Selected " + event.currentTarget.className);
        //console.log(props.getName);
        setColorSelected({ color: 'orange' });

      //  props.templateId("793759");
    }

    // useEffect(() => {
    //     setChecked((prev) => !prev);
    //     return () => {
    //         setChecked((prev) => !prev);
    //     };
    // }, []);

    return (
        <div className='template'>

            <Box className='mainContentBox'>

                <Box className='billHolder'>
                    {/* <Grow
                        in={checked}
                        style={{ transformOrigin: '0 0 0' }}
                        {...(checked ? { timeout: 1000 } : {})}
                    > */}
                        <Card ref={ref} className="card" onClick={templateSelected}  >
                            <Card.Img className="cardImage" variant="top" />
                            <Card.Body className="cardBody">
                                <img className='templateHolder' src={samplePdf2} />
                            </Card.Body>
                        </Card>
                    {/* </Grow> */}
                </Box>


            </Box>

      
        </div >
    )
}

export default SelectHtml
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import Grid from '@mui/material/Grid';
import MuiButton from '@mui/material/Button';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import Card from '@mui/material/Card';
import { Box } from '@mui/system';
import { BorderColor, Delete, Email, Payment, PeopleAlt, Sms } from '@mui/icons-material';
import { IconButton, Typography } from '@mui/material';
import {styled} from '@mui/material/styles';
import { useNavigate } from 'react-router-dom';

const columns = [
    {
        id : 'merchant',
        label : 'Merchant'
    },
    {
        id : 'emailSent',
        type: 'numeric',
        label: 'Total Emails Sent'
    },
    {
        id : 'smsSent',
        label: 'Total SMS Sent'
    },
    {
        id: 'transacCount',
        label: 'Transaction Count'
    },
    {
        id: 'subEndDate',
        label: 'Subscription End Date'
    }
]

function createData(
    merchant,
    emailAddress,
    role,
    startSubs,
    endSubs
) {
    return {
        merchant,
        emailAddress,
        role,
        startSubs,
        endSubs
    };
}



const rows = [
    createData('Merchant_11', 'Merchant_11@email.com', 'User', '05 November 2022', '05 January 2023'),
    createData('AzaPhil', 'AzaPhil@email.com', 'User', '03 January 2023', '03 March 2023'),
    createData('UAFSA', 'uafsa@email.com', 'User', '06 January 2023', '06 June 2023'),
    createData('AdCore', 'adcore@email.com', 'User', '04 October 2022', '04 October 2023'),
    createData('Prime League', 'primeleague@email.com', 'User', '10 April 2022', '10 April 2024'),
    createData('Test', 'test_1@email.com', 'User', '05 November 2022', '05 January 2023')
];

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));


const options = {
    shouldForwardProp: (prop) => prop !== 'rounded',
};

const Button = styled(
        MuiButton,
        options,
    )(({ rounded }) => ({
        borderRadius: rounded ? '24px' : null,
        backgroundColor: '#FD9A08'
  }));

function OnboardingPage() {
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(50);
    const navigate = useNavigate();

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    }; 

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };

    return (
        <div className='adminPage'>
            <div className='adminPageHeader'>
                <div >
                    <Grid
                        container
                        direction="row"
                        justifyContent="left"
                        alignItems="left"
                        columnGap={125}
                        display="flex"
                    >
                        <div className='title'>
                            Accounts
                        </div>
                        <Button onClick={() => {nextClick();}} 
                            variant="contained" size="large" disableElevation rounded>
                            + Create New Account
                        </Button>
                    </Grid>
                </div>
            </div>

            <div className='adminPageContent'>
                <div className='title'>
                    Overview
                </div>
                <Paper sx={{ width: '1400px', overflow: 'hidden'}}>
                    <TableContainer sx={{ maxHeight: 540 }}>
                        <Table sx={{minWidth: 700}}>
                            <TableHead>
                                <TableRow>
                                    <StyledTableCell align="center">Merchant</StyledTableCell>
                                    <StyledTableCell align="center">Email Address</StyledTableCell>
                                    <StyledTableCell align="center">Role</StyledTableCell>
                                    <StyledTableCell align="center">Subscription Start</StyledTableCell>
                                    <StyledTableCell align="center">Subscription End</StyledTableCell>
                                    <StyledTableCell align="center"> </StyledTableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {rows.map((row) => (
                                    <TableRow key={row.merchant}>
                                        <StyledTableCell align="center">{row.merchant}</StyledTableCell>
                                        <StyledTableCell align="center">{row.emailAddress}</StyledTableCell>
                                        <StyledTableCell align="center">{row.role}</StyledTableCell>
                                        <StyledTableCell align="center">{row.startSubs}</StyledTableCell>
                                        <StyledTableCell align="center">{row.endSubs}</StyledTableCell>
                                        <StyledTableCell align="center">
                                            <IconButton>
                                                <BorderColor/>
                                            </IconButton>
                                            <IconButton>
                                                <Delete />
                                            </IconButton>
                                        </StyledTableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Paper>
            </div>
        </div>
        
    );

    
    function nextClick() {
        navigate(process.env.REACT_APP_PATH + "/account");
    }

}

export default OnboardingPage
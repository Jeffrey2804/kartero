import React from 'react';
import Card from '@mui/material/Card';
import Email from '../../../Images/mapEmail.jpg';
import PDF from '../../../Images/mapPDF.jpg';
import Schedule from '../../../Images/setSchedule.jpg';
import SMS from '../../../Images/smsTemplate.jpg';
import { useNavigate } from 'react-router-dom';
import Stack from '@mui/material/Stack';
import AdminNavbar from '../../../Components/AdminNavbar';
import Sidebar from '../../../Components/Sidebar';
import '../../../Styles/AdminPage.css'
import OnboardingPage from './Components/OnboardingPage';

function Onboarding() {
    return(
        <div>
            <AdminNavbar/>
            <Sidebar/>
            <OnboardingPage/>
            {/* <div className='AdminPage'>
                <div className='pageHeader'>
                    Onboarding
                </div>
            </div> */}
        </div>
    );
}

export default Onboarding

import React from 'react';
import Login from './login/Login';
import { Route, Routes } from "react-router-dom";
import Home from "./home/HomePage";
import MainBillMenu from "./Bill/MainBillMenu";
import Report from './Report/Report';
import Subscription from './Subscription/Subscription';
import SessionTimeout from './Helper/SessionTimeout';
import LandingPage from './PaymentPage/LandingPage';
import SuccessPaymentPage from './PaymentPage/SuccessPayment';
import FailedPayment from './PaymentPage/FailedPayment';
import OTPPayment from './PaymentPage/OTPPayment';
import Account from './Admin/pages/Account/Account';
import Dashboard from './Admin/pages/Dashboard/Dashboard';
import DummyPaymentPage from './PaymentPage/DummyPaymentPage';
import Onboarding from './Admin/pages/Onboarding/Onboarding';
import MappingMainMenu from './Admin/pages/OnboardMap/MappingMainMenu';
import ExpiredLink from './PaymentPage/ExpireLinkPage';
import AdminPage from './Admin/AdminPage';
function App() {


  return (
    <div className="App">
      <Routes>

        <Route exact path={process.env.REACT_APP_PATH + "/"} element={<Login />} />
        <Route exact path={process.env.REACT_APP_PATH + "/login"} element={<Login />} />
        <Route exact path={process.env.REACT_APP_PATH + "/home"} element={<Home />} />
        <Route exact path={process.env.REACT_APP_PATH + "/bill"} element={<MainBillMenu />} />
        <Route exact path={process.env.REACT_APP_PATH + "/report"} element={<Report />} />
        <Route exact path={process.env.REACT_APP_PATH + "/subscription"} element={<Subscription />} />
        <Route exact path={process.env.REACT_APP_PATH + "/landingPage/:verificationCode"} element={<LandingPage />} />
        <Route exact path={process.env.REACT_APP_PATH + "/successPaymentPage"} element={<SuccessPaymentPage />} />
        <Route exact path={process.env.REACT_APP_PATH + "/failedPaymentPage"} element={<FailedPayment />} />
        <Route exact path={process.env.REACT_APP_PATH + "/expiredLink"} element={<ExpiredLink />} />
        <Route exact path={process.env.REACT_APP_PATH + "/otpPayment"} element={<OTPPayment />} />
        <Route exact path={process.env.REACT_APP_PATH + "/admin"} element={<AdminPage />} />
        <Route exact path={process.env.REACT_APP_PATH + "/dummyPaymentPage"} element={<DummyPaymentPage />} />
        <Route exact path={process.env.REACT_APP_PATH + "/account"} element={<Account />} />
        <Route exact path={process.env.REACT_APP_PATH + "/dashboard"} element={<Dashboard />} />
        <Route exact path={process.env.REACT_APP_PATH + "/onboarding"} element={<Onboarding />} />
        <Route exact path={process.env.REACT_APP_PATH + "/onboardMap"} element={<MappingMainMenu />} />
        <Route exact path="*" element={<>not exist</>} />
      </Routes>
      <SessionTimeout />
    </div >

  );
}

export default App;

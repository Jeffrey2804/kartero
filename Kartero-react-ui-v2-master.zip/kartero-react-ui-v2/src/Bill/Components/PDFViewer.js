import React,{useState} from 'react';
import DocViewer from "react-doc-viewer";
import { Document, Page } from 'react-pdf/dist/esm/entry.webpack';
import PDFFile from "../../Files/statement_template.pdf";
function PDFViewer() {
    const [numPages, setNumPages] = useState(null);
    const [pageNumber, setPageNumber] = useState(1);

    const [file, setFile] = useState('./sample.pdf');
    
    function onDocumentLoadSuccess({ numPages }) {
        setNumPages(numPages);
    }

    return (
        <div>
            <Document file={PDFFile} onLoadSuccess={onDocumentLoadSuccess}>
                <Page pageNumber={pageNumber} />
            </Document>
            <p>
                Page {pageNumber} of {numPages}
            </p>
        </div>
    )
}

export default PDFViewer
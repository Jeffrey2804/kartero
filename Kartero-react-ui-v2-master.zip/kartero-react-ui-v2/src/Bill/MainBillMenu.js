import React from 'react'
import Navbar from '../Components/Navbar'

import BreadCrumbs from 'react-bootstrap/Breadcrumb';
import KarteroStepper from '../Bill/Components/KarteroStepper'
import Template from './Template/Template';

function MainBilling(props) {
  
  const pull_data = (data) => {
    console.log(data); // LOGS DATA FROM CHILD (My name is Dean Winchester... &)
  }

  return (
    <div className='mainBillMenu'>
      <Navbar />
  
      <KarteroStepper />
       
    </div>
  )
}

export default MainBilling
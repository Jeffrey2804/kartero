import React, { useState, useEffect, useRef } from 'react'
import '../../Styles/Preview.css';
import Box from '@mui/material/Box';
import Card from 'react-bootstrap/Card';
import Grow from '@mui/material/Grow';

import samplePdf from '../../Images/samplePdf.png';
import sampleSms from '../../Images/sms.png';
import sampleEmail from '../../Images/email.png';

import Stack from '@mui/material/Stack';
function Preview() {
  const [checked, setChecked] = React.useState(false);
  const ref = useRef(null);

  useEffect(() => {
    setChecked((prev) => !prev);
    return () => {
      setChecked((prev) => !prev);
    };
  }, []);

  return (
    <div className='preview'>

      <Box className='mainContentBox'>

        <Box className='componentHolder'>
          <Grow
            in={checked}
            style={{ transformOrigin: '0 0 0' }}
            {...(checked ? { timeout: 1000 } : {})}
          >
            <Card ref={ref} className="card" >
              <Card.Img className="cardImage" variant="top" />
              <Card.Body className="cardBody">
                <Stack spacing={1} direction="column" alignItems="center">
                <Card.Text className='cardText'>
                    EMAIL TEMPLATE
                  </Card.Text>
                  <img className='componentHolder' src={sampleEmail} />
                
                </Stack>
              </Card.Body>
            </Card>
          </Grow>
          <Grow
            in={checked}
            style={{ transformOrigin: '0 0 0' }}
            {...(checked ? { timeout: 1000 } : {})}
          >
            <Card ref={ref} className="card" >
              <Card.Img className="cardImage" variant="top" />
              <Card.Body className="cardBody">
                <Stack spacing={1} direction="column" alignItems="center">
                <Card.Text className='cardText'>
                    SMS TEMPLATE
                  </Card.Text>
                  <img className='componentHolder' src={sampleSms} />
                 
                </Stack>
              </Card.Body>
            </Card>
          </Grow>
          <Grow
            in={checked}
            style={{ transformOrigin: '0 0 0' }}
            {...(checked ? { timeout: 1000 } : {})}
          >
            <Card ref={ref} className="card" >
              <Card.Img className="cardImage" variant="top" />
              <Card.Body className="cardBody">
                <Stack spacing={1} direction="column" alignItems="center">
                  <Card.Text className='cardText'>
                    PDF TEMPLATE
                  </Card.Text>
                  <img className='componentHolder' src={samplePdf} />

                </Stack>
              </Card.Body>
            </Card>
          </Grow>


        </Box>


      </Box>

    </div>
  )
}

export default Preview
import React from 'react'
import TablePreview from './TablePreview';
import '../../Styles/Review.css';
function Review(props) {
  return (
    <div className='review'>
      
      <TablePreview dataFromUpload={props.dataFromUpload}/>
    </div>
  )
}

export default Review
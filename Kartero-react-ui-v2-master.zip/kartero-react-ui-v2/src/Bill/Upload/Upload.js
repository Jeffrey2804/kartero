import React, {
  useEffect,
  useRef,
  useState
} from "react";
import '../../Styles/Upload.css';
import FileDropZone from "../Components/FileDropZone";
function Upload(props) {

  const fileChooserRef = useRef();
  const handleDropItems = (items) => {

    if (items.length > 0) {

      //setOpenImportModal(true);
      //setDroppedItems(items);
      // console.log("import" + items);
    }
  };

  const handleUpload = (items) => {
    // console.log(props.templateId);

    try {
      props.uploadData(items);

    } catch (e) {
      console.log('Error')
    }

   

  }

  return (
    <div className='upload'>

      <FileDropZone
        ref={fileChooserRef}
        onFilesDropped={handleDropItems}
        uploadFile={handleUpload}
      />

    </div>
  )
}

export default Upload
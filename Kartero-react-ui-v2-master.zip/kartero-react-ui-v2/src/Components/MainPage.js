import React from 'react'
import '../Styles/MainPage.css'
export default function MainPage() {
  return (
    <div className='mainPage'>
        <h1>Welcome to the Website</h1>
        <button>Click me</button>
    </div>
   
  )
}

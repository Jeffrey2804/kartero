import React from 'react';
import Radio from '@mui/material/Radio';

export const SidebarData = [
    {
        title : "Dashboard",
        icon : "",
        link : process.env.REACT_APP_PATH + "/dashboard"
    },
    // {
    //     title : "Accounts",
    //     icon : "",
    //     link : process.env.REACT_APP_PATH + "/account"
    // },
    // {
    //     title : "SOA Creation",
    //     icon : "",
    //     link : process.env.REACT_APP_PATH + "/soa-creation"
    // },
    // {
    //     title : "Application Settings",
    //     icon : "",
    //     link : process.env.REACT_APP_PATH + "/app-settings"
    // },
    // {
    //     title : "Profile",
    //     icon : "",
    //     link : process.env.REACT_APP_PATH + "/profile"
    // },
    // {
    //     title : "Payment Reports",
    //     icon : "",
    //     link : process.env.REACT_APP_PATH + "/payment-reports"
    // }
    {
        title : "Onboarding",
        icon : "",
        link : process.env.REACT_APP_PATH + "/onboarding"
    }
];


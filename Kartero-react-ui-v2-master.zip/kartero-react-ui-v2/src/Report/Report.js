import React,{ useState } from 'react'
import Navbar from '../Components/Navbar'
import KarteroTab from './Components/KarteroTab'
import PaymentBatchOverview from './Components/PaymentBatchOverview'
import PaymentIndividualOverview from './Components/PaymentIndividualOverview'

function Report() {



  return (
    <div className='report'>
        <Navbar/>
        <KarteroTab/>
        {/* <BatchOverview/> */}
    </div>
  )
}

export default Report
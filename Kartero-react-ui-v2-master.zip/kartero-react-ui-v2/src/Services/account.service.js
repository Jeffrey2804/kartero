import axios from "axios";
import { authHeader } from "../Helper/Auth-header";
import jwt_decode from "jwt-decode";
import Cookies from "universal-cookie";
export const accountService ={
  getAccountByEmail,
  getAllAccount,
};


function getAccountByEmail(emailAddress) {
  return axios
    .get(`${process.env.REACT_APP_API_URL}/gateway-service/accounts-service/users/u/${emailAddress}`, {
      headers: authHeader(),
    })
    .then((response) => response.data)
    .catch((error) => Promise.reject(error.response));

}

function getAllAccount() {
  return axios
    .get(`${process.env.REACT_APP_API_URL + process.env.REACT_APP_API_GATEWAY}/users`, {
      headers: authHeader(),
    })
    .then((response) => response.data)
    .catch((error) => Promise.reject(error.response));

    
}
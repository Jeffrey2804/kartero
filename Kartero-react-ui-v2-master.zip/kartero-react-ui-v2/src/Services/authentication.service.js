import axiosInstance from "../Helper/axios.instance";
import Cookies from "universal-cookie";
import { authHeader } from "../Helper/Auth-header";
export const authenticationService = {
  login,
  logout,
  hasToken,
  extractData,
  hasRefreshToken,
};

const cookies = new Cookies();

function login(username, password) {
  return axiosInstance
    // .post(`http://192.168.1.163:8080/dit-api-gateway/api/auth`, {
    .post(`${process.env.REACT_APP_API_URL  + process.env.REACT_APP_API_GATEWAY}/auth`, {
      username,
      password,

    })
    .then((response) => {
      cookies.set("karteroId", response.data, { path: "/" });
      cookies.set("karteroRefreshToken", response.data.refreshToken, { path: "/" });
      console.log(response.data);

      return Promise.resolve("logged in");
    })
    .catch((error) => Promise.reject(error));
}

function extractData() {
  return (

    axiosInstance
      .post(`${process.env.REACT_APP_API_URL + process.env.REACT_APP_API_GATEWAY}/auth/extract`, {
      
        token:hasToken(),
        refreshToken:"",
      })
      .then((response) => response.data)
      .catch((error) => Promise.reject(error.response))
  );
}



function logout() {
  cookies.remove("karteroId", { path: "/" });
  return Promise.resolve("logged out");
}

function hasToken() {
  return cookies.get("karteroId") && cookies.get("karteroId").token;
}

function hasRefreshToken() {
  return cookies.get("karteroRefreshToken") && cookies.get("karteroRefreshToken").refreshToken;
}
import axios from "axios";
import { authHeader } from "../Helper/Auth-header";
import jwt_decode from "jwt-decode";
import Cookies from "universal-cookie";
import { authenticationService } from "./authentication.service";
export const templateService = {
  uploadFile,
};

function uploadFile(name, file) {
  const byteFile = readFileDataAsBase64(file);
  const formData = new FormData();
  formData.append('file', file);
  formData.append('templateId', "7b16102b-65ab-466b-bd86-31ba4d158043");
  const config = {
    headers: {
      Authorization: `Bearer ` + authenticationService.hasToken(),
      'content-type': 'multipart/form-data'
    }
  }
  return axios
    .post(`${process.env.REACT_APP_API_URL}/gateway-service/template-service/upload/customer`,
      formData,
      config)
    .then((response) => response.data)
    .catch((error) => Promise.reject(error.response));
}

function readFileDataAsBase64(e) {
  const file = e;

  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (event) => {
      resolve(event.target.result);
    };

    reader.onerror = (err) => {
      reject(err);
    };

    reader.readAsDataURL(file);
  });
}

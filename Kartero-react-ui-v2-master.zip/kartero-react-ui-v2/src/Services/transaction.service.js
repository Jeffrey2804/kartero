import axios from "axios";
import { authHeader } from "../Helper/Auth-header";

import { authenticationService } from "./authentication.service";
export const transactionService = {
    startSendTransaction,

};


function startSendTransaction(uploadedData, merchantId) {

    const config = {
        headers: {
            Authorization: `Bearer ` + authenticationService.hasToken(),
            'content-type': 'application/json'
        }
    }

    return axios
        .post(`${process.env.REACT_APP_API_URL}/gateway-service/transaction-service/batch/` + merchantId + `/save-requests`,
            uploadedData, config

        )
        .then((response) => response.data)
        .catch((error) => Promise.reject(error.response));
}

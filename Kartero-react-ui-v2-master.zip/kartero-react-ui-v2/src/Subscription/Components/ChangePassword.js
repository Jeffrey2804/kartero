import React from 'react'
import '../../Styles/ManageSubscription.css'
import TextField from '@mui/material/TextField';

import Stack from '@mui/material/Stack';

import Button from '@mui/material/Button';
function ChangePassword() {
    return (
        <div className='changePassword'>



            <Stack spacing={2} direction="row" alignItems="left">

                <Stack spacing={2} direction="column" alignItems="left">
                    <div className='titleHolder'>Email Address :</div>
                    <div className='titleHolder'>Old Password :</div>
                    <div className='titleHolder'>New Password :</div>
                    <div className='titleHolder'>Confirm Password :</div>

                </Stack>
                <Stack spacing={2} direction="column" alignItems="left">

                    <TextField
                        hiddenLabel
                        id="filled-hidden-label-small"

                        variant="outlined"
                        size="small"
                    />

                    <TextField
                        hiddenLabel
                        id="filled-hidden-label-small"

                        variant="outlined"
                        size="small"
                    />

                    <TextField
                        hiddenLabel
                        id="filled-hidden-label-small"

                        variant="outlined"
                        size="small"
                    />
                    <TextField
                        hiddenLabel
                        id="filled-hidden-label-small"

                        variant="outlined"
                        size="small"
                    />

                    <Button variant="contained" className="sendButton" >
                        Confirm
                    </Button>
                </Stack>



            </Stack>


        </div>
    )
}

export default ChangePassword
import React from 'react'
import '../../Styles/ManageSubscription.css'
import TextField from '@mui/material/TextField';
import SendIcon from '@mui/icons-material/Send';
import Button from '@mui/material/Button';
import ContactSupportImage from '../../Images/support.png';

import Stack from '@mui/material/Stack';

function ContactSupport() {
    return (
        <div className='contactSupport'>


            <Stack 
              direction="row"
              justifyContent="flex-start"
              alignItems="center"
              spacing={2}>

                <img src={ContactSupportImage} className='supportImage' />

                <Stack spacing={5} direction="column" alignItems="left">
                    <Stack direction="column" alignItems="left">

                        <div className='supportName'>Juan J. Dela Cruz</div>
                        <div className='supportPosition'>Kartero Support Representative</div>
                    </Stack>
                    <Stack spacing={1} direction="column" alignItems="left">
                        <div className='supportMessage'>You may contact our representiative through:</div>
                    </Stack>
                    <Stack spacing={1} direction="column" alignItems="left">
                        <div className='supportNumber'>(+63)999-123-4567</div>
                        <div className='supportEmail'>jdelacruz@gmail.com</div>
                    </Stack>
                </Stack>

            </Stack>


        </div>
    )
}

export default ContactSupport
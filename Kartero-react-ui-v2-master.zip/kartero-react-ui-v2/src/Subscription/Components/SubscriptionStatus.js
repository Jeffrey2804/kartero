import React from 'react'
import '../../Styles/ManageSubscription.css';

import Stack from '@mui/material/Stack';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import { useState } from 'react';
function SubscriptionStatus() {



    return (
        <div className='subscriptionStatus'>




            <Box sx={{ width: '100%' }}>
                <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                    <Grid item xs={2.5}>
                        <div className='titleHolder'> Current Billing Cycle :</div>

                    </Grid>
                    <Grid item xs={9}>
                        <div className='content'> 2022 May-June</div>

                    </Grid>
                    <Grid item xs={2.5}>
                        <div className='titleHolder'> Email Remaining :</div>

                    </Grid>
                    <Grid item xs={9}>
                        <div className='content'>125/5000</div>

                    </Grid>
                    <Grid item xs={2.5}>
                        <div className='titleHolder'>SMS Remaining :</div>

                    </Grid>
                    <Grid item xs={9}>
                        <div className='content'>125/5000</div>

                    </Grid>
                    <Grid item xs={2.5}>
                        <div className='titleHolder'>Valid Until :</div>

                    </Grid>
                    <Grid item xs={9}>
                        <div className='content'>2022 July 1</div>

                    </Grid>
                </Grid>
            </Box>

        </div>
    )
}

export default SubscriptionStatus
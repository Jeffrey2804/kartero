import * as React from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import SubscriptionStatus from './SubscriptionStatus';
import SelectTemplate from './SelectTemplate';
import ChangePassword from '../Components/ChangePassword';
import ContactSupport from './ContactSupport';
import RunScheduler from './RunScheduler';
import { createTheme, ThemeProvider } from '@mui/material/styles';

const theme = createTheme({
    palette: {
        primary: {

            main: '#FD9A08',
        },
        secondary: {

            main: '#11cb5f',
        },
    },
});


function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 3 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

export default function BasicTabs() {
    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    return (
        <ThemeProvider theme={theme}>
            <Box sx={{ width: '100%', height: '100%' }}>
                <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                    <Tabs value={value} onChange={handleChange} aria-label="Subscription Page"
                        variant="scrollable"
                        scrollButtons="auto"
                    >
                        <Tab className='tabHeader' label="Subscription Status" {...a11yProps(0)} />
                        <Tab className='tabHeader' label="Change Password" {...a11yProps(1)} />
                        <Tab className='tabHeader' label="Contact Support" {...a11yProps(2)} />
                        <Tab className='tabHeader' label="Select Template" {...a11yProps(3)} />
                        <Tab className='tabHeader' label="Run Scheduler" {...a11yProps(4)} />
                    </Tabs>
                </Box>
                <TabPanel value={value} index={0}>
                    <SubscriptionStatus />
                </TabPanel>
                <TabPanel value={value} index={1}>
                    <ChangePassword />
                </TabPanel>
                <TabPanel value={value} index={2}>
                    <ContactSupport />
                </TabPanel>
                <TabPanel value={value} index={3}>
                    <SelectTemplate />
                </TabPanel>
                <TabPanel value={value} index={4}>
                    <RunScheduler />
                </TabPanel>
            </Box>
        </ThemeProvider>
    );
}

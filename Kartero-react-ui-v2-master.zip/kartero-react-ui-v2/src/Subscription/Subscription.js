import React from 'react'
import { TabPane } from 'react-bootstrap'
import Navbar from '../Components/Navbar'
import TabPanel from './Components/Tabpanel';
import '../Styles/ManageSubscription.css';
function Subscription() {
  return (
    <div className='manageSubscription'>
      <Navbar />
      <TabPanel />
    </div>
  )
}

export default Subscription
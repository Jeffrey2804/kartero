import React from 'react'
import Navbar from '../Components/Navbar'
import "../Styles/HomePage.css"
// import MainMenu from './pages/MaineMenu'

import MainMenu from './pages/MainMenu'
import WelcomeMessage from './pages/WelcomeMessage'
function HomePage() {
  return (
    <div className='homePage'>
        <Navbar/>
        <WelcomeMessage/>
        <MainMenu/>
    </div>
  )
}

export default HomePage
import React from 'react'
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Upload from '../../Images/upload.png';
import Report from '../../Images/report.png';
import Manage from '../../Images/manage.png';
import "../../Styles/HomePage.css"
import { useNavigate } from "react-router-dom";

import Grid from '@mui/material/Grid';
import Stack from '@mui/material/Stack';

import Box from '@mui/material/Box';
function MaineMenu2() {
    const navigate = useNavigate();
    function goTo(pageName) {
        navigate(pageName);
    }
    return (
        <div className='mainMenu'>
            <div className='cards'>




                <Box sx={{ width: '100%', height:'100%' }}>
                    <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                        <Grid item xs>
                            <Card
                                onClick={() => {
                                    goTo(process.env.REACT_APP_PATH + "/bill");
                                }}
                                className="card" >
                                <Stack spacing={1} direction="column" alignItems="center">

                                    <Card.Img className="cardImage" variant="top" src={Upload} />
                                    <Card.Title className='cardTitle'>UPLOAD BILLING</Card.Title>

                                    <Card.Body >

                                        <Stack spacing={1} direction="column" alignItems="center">

                                            <Card.Text className='cardText'>
                                                CURRENT SUBSCRIPTION UNTIL :
                                            </Card.Text>
                                            <Card.Text className='cardDate'>
                                                99/99/9999
                                            </Card.Text>
                                            <Card.Text >

                                            </Card.Text>
                                        </Stack>
                                    </Card.Body>
                                </Stack>
                            </Card>
                        </Grid>
                        <Grid item xs>
                            <Card
                                onClick={() => {
                                    goTo(process.env.REACT_APP_PATH + "/report");
                                }}
                                className="card" >
                                <Stack spacing={1} direction="column" alignItems="center">

                                    <Card.Img className="cardImage" variant="top" src={Report} />
                                    <Card.Title className='cardTitle'>REPORT STATUS</Card.Title>

                                    <Card.Body >

                                        <Stack spacing={1} direction="column" alignItems="center">

                                            {/* <Card.Text className='cardText'>
                                                CURRENT SUBSCRIPTION UNTIL :
                                            </Card.Text>
                                            <Card.Text className='cardDate'>
                                                99/99/9999
                                            </Card.Text>
                                            <Card.Text >

                                            </Card.Text> */}
                                        </Stack>
                                    </Card.Body>
                                </Stack>
                            </Card>
                        </Grid>
                        <Grid item xs>
                            <Card
                                onClick={() => {
                                    goTo(process.env.REACT_APP_PATH + "/subscription");
                                }}
                                className="card" >
                                <Stack spacing={1} direction="column" alignItems="center">

                                    <Card.Img className="cardImage" variant="top" src={Manage} />
                                    <Card.Title className='cardTitle'>MANAGE SUBSCRIPTION</Card.Title>

                                    <Card.Body >

                                        <Stack spacing={1} direction="column" alignItems="center">

                                            {/* <Card.Text className='cardText'>
                                                CURRENT SUBSCRIPTION UNTIL :
                                            </Card.Text>
                                            <Card.Text className='cardDate'>
                                                99/99/9999
                                            </Card.Text>
                                            <Card.Text >

                                            </Card.Text> */}
                                        </Stack>
                                    </Card.Body>
                                </Stack>
                            </Card>
                        </Grid>
                    </Grid>
                </Box>

            </div>
        </div >
    )
}

export default MaineMenu2
import React, { useState } from "react";
import "../../Styles/LoginPage.css";
import logo from '../../Images/logo-white.png';
import { useNavigate } from "react-router-dom";
import { authenticationService } from '../../Services/authentication.service';
import ReCAPTCHA from 'react-google-recaptcha';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});
const recaptchaRef = React.createRef();
function LoginForm() {
    const [open, setOpen] = useState(false);
    const [severity, setSeverity] = useState("info");
    const [snackMessage, setSnackMessage] = useState("");
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [isVerified, setIsverified] = useState(true);
    const navigate = useNavigate();
    function onChange(value) {
        setIsverified(!value == null);
    }




    function loginClick() {
        if (!isVerified) {
            authenticationService
                .login(username, password)
                .then(() => {
                    navigate(process.env.REACT_APP_PATH + "/home", { replace: true });
                })
                .catch((error) => {
                    setSeverity("error");
                    setSnackMessage(error.response.data);
                    if (error.response.data == null) setSnackMessage(error.message);
                    setOpen(true);
                });
        }
    }

    window.onload = () => {

        setIsverified(true);
    }

    const handleExpire = () => {
        setIsverified(true);
    }

    const handleKeyDown = (event) => {
        if (event.key === 'Enter') {
            loginClick();
        }
    }
    const handleUserTypeChange = (event) => {
        setUsername(event.target.value);
    }
    const handlePassTypeChange = (event) => {
        setPassword(event.target.value);
    }
    const handleClose = (reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpen(false);
    };
    return (
        <div className='LoginForm'>
            <div>
                <img className='logoImage' src={logo} />
                <input value={username}
                    onChange={handleUserTypeChange}
                    onKeyDown={handleKeyDown}
                    className='usernameTextBox' type="text" placeholder="Username" ></input><br />
                <input value={password}
                    onChange={handlePassTypeChange}
                    onKeyDown={handleKeyDown}
                    className='passwordTextBox' type="password" placeholder="Password" ></input><br />



                <ReCAPTCHA
                    className="captcha"
                    size="normal"
                    type="image"
                    ref={recaptchaRef}
                    onExpired={handleExpire}
                    sitekey="6Ld4AFsiAAAAANQmwlRNu65UFUlUKS_oz0gMecCl"
                    onChange={onChange}
                />
                {/* {!isVerified ? */}
                <Stack
                    direction="column"
                    justifyContent="center"
                    alignItems="center"
                    spacing={2}
                >
                    <button
                        onClick={() => { loginClick(); }}
                        disabled={isVerified}
                        className='loginButton'>
                        LOGIN
                    </button>
                    <button onClick={() => { adminClick(); }}
                        disabled={isVerified}
                        className='loginButton'>
                        Admin
                    </button>
                    {/* <button onClick={() => { testClick(); }}
                       
                        className='loginButton'>
                        test
                    </button> */}
                </Stack>


                {/* : null} */}

            </div>
            <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
                <Alert onClose={handleClose} severity={severity} sx={{ width: '100%' }}>
                    {snackMessage}
                </Alert>
            </Snackbar>
        </div>
    )

    function adminClick() {

        navigate(process.env.REACT_APP_PATH + "/admin");

    }

    function testClick() {
        navigate(process.env.REACT_APP_PATH + "/failedPaymentPage");
    }
}
export default LoginForm
